/**
 * 
 */

function validateCompanyRegistrationForm() {

	var EmpName = document.forms["employeeRegistrationForm"]["EmpName"].value;
	var EmailId = document.forms["employeeRegistrationForm"]["EmailId"].value;

	var formSubmittionStatus = true;

	if (EmpName == "") {
		formSubmittionStatus = false;
	} else if (EmailId = "") {
		formSubmittionStatus = false;
	} else {
	}

	if (!formSubmittionStatus) {
		alert("Invalid form");
	} else {
		alert("Form validation success.....");

	}

	return formSubmittionStatus;

}

function validateEmployeeRegistrationForm(){

	var EmpName = document.forms["employeeRegistrationForm"]["empName"].value;
	

	var formSubmittionStatus = true;

	if (EmpName == "") {
		formSubmittionStatus = false;
	} 
	 else {
	}

	if (!formSubmittionStatus) {
		alert("Invalid Employee Name");
	} else {
		alert("Form validation success.....");

	}
	
	var x=document.forms["employeeRegistrationForm"]["emailId"].value; 
	var atposition=x.indexOf("@");  
	var dotposition=x.lastIndexOf(".");  
	if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
	  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
	  formSubmittionStatus = false;  
	  }  
	
	var phn=document.forms["employeeRegistrationForm"]["contactNo"].value;
	var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
	  if((phn.value.match(phoneno))
	        {
		  formSubmittionStatus = true;
	        }
	      else
	        {
	        alert("message");
	        formSubmittionStatus = false; 
	        }

	return formSubmittionStatus;

}
function myFunction()
{
	var username1="admin";
	var password1="admin";
	var username2=document.frm.username.value;
	var password2=document.frm.password.value;
	if((username1==username2)&&(password1==password2))
		{
		alert("Login Successfull.....");
		return true;
		}
	else
		{
		alert("Invalid Details");
		return false;
		}
	}