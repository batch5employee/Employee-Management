package com.example.Employee_management.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp_details")
public class EmployeeEntity {
	
	@Override
	public String toString() {
		return "EmployeeEntity [empid=" + empid + ", empName=" + empName + ", salary=" + salary + ", empDesignation="
				+ empDesignation + ", contactNo=" + contactNo + ", emailId=" + emailId + "]";
	}
	@Id
	@GeneratedValue
	private int empid;
	@Column(name="Employee_name")
	private String empName;
	private double salary;
	private String empDesignation;
	private int contactNo;
	private String emailId;
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
}