package com.example.Employee_management.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Employee_management.EmployeeRepository.EmployeeRepository;
import com.example.Employee_management.entity.EmployeeEntity;
import com.example.Employee_management.pojo.EmployeePojo;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public EmployeePojo save(EmployeePojo employeePojo) {
		System.out.println("Service..." + employeePojo.getEmpName());

		EmployeeEntity employee = new EmployeeEntity();
		employee.setEmpName(employeePojo.getEmpName());
		employee.setEmpDesignation(employeePojo.getEmpDesignation());
		employee.setContactNo(employeePojo.getContactNo());
		employee.setEmailId(employeePojo.getEmailId());
		employee.setSalary(employeePojo.getSalary());
		

	   employeeRepository.save(employee);

		employeePojo.setEmpid(employee.getEmpid());

		return employeePojo;
	}

	@Override
	public List<EmployeePojo> list() {

		List<EmployeePojo> employeePojoList = new ArrayList<EmployeePojo>();

		List<EmployeeEntity> employeeList = employeeRepository.findAll();

		for (EmployeeEntity employee :  employeeList) {
			EmployeePojo  employeePojo = new EmployeePojo();
			employeePojo.setEmpid(employee.getEmpid());
			 employeePojo.setEmpName(employee.getEmpName());
			employeePojo.setEmpDesignation(employee.getEmpDesignation());
			employeePojo.setContactNo(employee.getContactNo());
			employeePojo.setEmailId(employee.getEmailId());
			employeePojo.setSalary(employee.getSalary());
			
			employeePojoList.add(employeePojo);
			System.out.println(employee.getEmpid());
			System.out.println(employee.getEmpName());
		}

		return employeePojoList;

	}

	@Override
	public EmployeePojo get(int empid) {
		EmployeeEntity employee=employeeRepository.getOne(empid);

		EmployeePojo employeePojo = new EmployeePojo();
		employeePojo.setEmpName(employee.getEmpName());
		employeePojo.setEmpid(employee.getEmpid());
		employeePojo.setEmpDesignation(employee.getEmpDesignation());
		employeePojo.setContactNo(employee.getContactNo());
		employeePojo.setEmailId(employee.getEmailId());
		employeePojo.setSalary(employee.getSalary());

		return employeePojo;
	}

	@Override
	public void update(EmployeePojo employeePojo) {
		
		EmployeeEntity employee = new EmployeeEntity();
		employee.setEmpid(employeePojo.getEmpid());
		employee.setEmpName(employeePojo.getEmpName());
		employee.setEmpDesignation(employeePojo.getEmpDesignation());
		employee.setContactNo(employeePojo.getContactNo());
		employee.setEmailId(employeePojo.getEmailId());
		employee.setSalary(employeePojo.getSalary());
		
		employeeRepository.save(employee);
		
	}

	@Override
	public void deleteEmployee(int empid) {
		employeeRepository.deleteById(empid);
	}

	@Override
	public EmployeePojo search(int empid) {
		
		EmployeeEntity emp = employeeRepository.findById(empid).orElse(new EmployeeEntity());
		EmployeePojo employeePojo = new EmployeePojo();
		employeePojo.setEmpid(emp.getEmpid());
		employeePojo.setEmpName(emp.getEmpName());
		employeePojo.setEmpDesignation(emp.getEmpDesignation());
		employeePojo.setSalary(emp.getSalary());
		employeePojo.setContactNo(emp.getContactNo());
		employeePojo.setEmailId(emp.getEmailId());
		System.out.println(emp.getEmpName());
		return employeePojo;
	}
	 
	

	
}
