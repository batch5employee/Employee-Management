package com.example.Employee_management.service;

import java.util.List;

import com.example.Employee_management.pojo.EmployeePojo;


public interface EmployeeService {

	EmployeePojo  save(EmployeePojo employeePojo);

	List<EmployeePojo > list();

	EmployeePojo  get(int empid);
	
	void update(EmployeePojo employeePojo);

	void deleteEmployee(int empid);

    EmployeePojo search(int empid);
}
