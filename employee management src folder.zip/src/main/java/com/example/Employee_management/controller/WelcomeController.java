package com.example.Employee_management.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.Employee_management.pojo.EmployeePojo;
import com.example.Employee_management.service.EmployeeService;
@Controller
public class WelcomeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/")
	String loginPage() {

		return "login";
	}


	@GetMapping("/homepg")
	String welcome() {

		return "Welcome";
	}
	@PostMapping("/showWelcome")
	String welcomePage() {

		return "Welcome";
	}

	@GetMapping("/forgotpasswardmap")
	String forgot() {
		
		return "forgotpassword";
	}
	
	
	
	
	
	
	
	@GetMapping("/showEmployeeForm")
	String showEmployeeForm(ModelMap model) {
		model.addAttribute("employeePojo", new EmployeePojo());
		return "EmployeeForm";
	}

	@PostMapping(value = "/registerEmployee")
	public String registerEmployee(@ModelAttribute("employeePojo") EmployeePojo c) {

		System.out.println(c.getEmpid());
		System.out.println(c.getEmpName());

		employeeService.save(c);

		return "registersuccesful";
	}

	@GetMapping(value = "/listEmployee")
	public String listEmployee(ModelMap model) {

		List<EmployeePojo> employeePojoList = employeeService.list();
		model.addAttribute("employeePojoListObj", employeePojoList);

		return "showEmployeeList";
	}

	
	
	@GetMapping(value = "/search")
	public String listEmployee1 (ModelMap model) {

		List<EmployeePojo> employeePojoList = employeeService.list();
		model.addAttribute("employeePojoListObj", employeePojoList);

		return "searchresult";
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping(value = "/showEditForm")
	public String editEmployee(@RequestParam int id, ModelMap model) {

		System.out.println("Value passed com id ..." + id);
		EmployeePojo employeePojo = employeeService.get(id);
		model.addAttribute("employeePojo", employeePojo);

		return "editEmployeeDetails";
	}

	@PostMapping(value = "/editEmployeeDetails")
	public String editEmployee(@ModelAttribute("employeePojo") EmployeePojo c) {

		employeeService.update(c);

		return "redirect:listEmployee";
	}

	@GetMapping(value = "/deleteEmployee")
	public String deleteEmployee(@RequestParam int id) {

		employeeService.deleteEmployee(id);

		return "redirect:listEmployee";
	}

	@GetMapping("/searchemp")
	public ModelAndView search (@RequestParam int id) 
	{
		ModelAndView mv = new ModelAndView("searchlist");
		mv.addObject(employeeService.search(id));
		return mv;
	}
	
	
	@GetMapping("/searchempbyid")
	String searchbyid() {
		
		return "searchbyempid";
	}

}
